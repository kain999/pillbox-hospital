resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'The ultimate IPL loader for FiveM'

version '1.0.0'

client_scripts {
	'iplList.lua',
	'client.lua'
}